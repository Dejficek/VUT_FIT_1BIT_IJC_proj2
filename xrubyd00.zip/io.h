/*
 * David Rubý
 * fakulta informačních technologií Vysokého učení technického v Brně
 * příklad 2
 *25. 04. 2019
 */

#include<stdio.h>
#include<ctype.h>
#include<string.h>

int get_word(char *str, int max, FILE *file);